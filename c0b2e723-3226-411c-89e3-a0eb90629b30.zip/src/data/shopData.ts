export interface Product {
  id: number;
  name: string;
  type: string;
  price: string;
  image: string;
  description: string;
  specs: {label: string;value: string;}[];
}

export const productsData: Product[] = [
{
  id: 1,
  name: 'EcoTherm Pro Boiler',
  type: 'Heating Unit',
  price: '$2,499',
  image:
  'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'High-efficiency condensing boiler designed for modern residential heating. Delivers consistent hot water and space heating with minimal energy waste.',
  specs: [
  { label: 'Efficiency', value: '95% AFUE' },
  { label: 'Fuel Type', value: 'Natural Gas / Propane' },
  { label: 'Warranty', value: '10 Years' }]

},
{
  id: 2,
  name: 'SmartFlow Radiator',
  type: 'Heat Distribution',
  price: '$450',
  image:
  'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'Architectural panel radiator with integrated smart thermostatic controls. Sleek design fits any modern interior while providing rapid heat distribution.',
  specs: [
  { label: 'Material', value: 'Powder-coated Steel' },
  { label: 'Output', value: '5000 BTU/hr' },
  { label: 'Connectivity', value: 'Wi-Fi enabled' }]

},
{
  id: 3,
  name: 'AeroCool Inverter AC',
  type: 'Cooling System',
  price: '$1,850',
  image:
  'https://images.unsplash.com/photo-1558002038-1055907df827?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'Ultra-quiet ductless mini-split air conditioner. Uses advanced inverter technology to maintain precise temperatures while reducing electricity consumption.',
  specs: [
  { label: 'SEER Rating', value: '22' },
  { label: 'Noise Level', value: '19 dB' },
  { label: 'Coverage', value: 'Up to 800 sq ft' }]

},
{
  id: 4,
  name: 'PureWater Filtration Hub',
  type: 'Plumbing Accessory',
  price: '$899',
  image:
  'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'Whole-house water filtration and descaling system. Protects your plumbing infrastructure and appliances from hard water damage.',
  specs: [
  { label: 'Flow Rate', value: '15 GPM' },
  { label: 'Filter Life', value: '100,000 Gallons' },
  { label: 'Maintenance', value: 'Annual' }]

},
{
  id: 5,
  name: 'RadiantFloor Mat System',
  type: 'Floor Heating',
  price: '$12/sq ft',
  image:
  'https://images.unsplash.com/photo-1513694203232-719a280e022f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'Electric radiant floor heating mats designed for easy installation under tile, stone, or engineered wood floors.',
  specs: [
  { label: 'Voltage', value: '120V / 240V' },
  { label: 'Thickness', value: '1/8 inch' },
  { label: 'Control', value: 'Smart Thermostat required' }]

},
{
  id: 6,
  name: 'Industrial Circulator Pump',
  type: 'Plumbing Accessory',
  price: '$320',
  image:
  'https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'Heavy-duty cast iron circulator pump for demanding heating and cooling systems. Ensures reliable fluid movement across large networks.',
  specs: [
  { label: 'Max Pressure', value: '150 PSI' },
  { label: 'Material', value: 'Cast Iron' },
  { label: 'Power', value: '1/6 HP' }]

},
{
  id: 7,
  name: 'Smart Climate Hub',
  type: 'System Control',
  price: '$299',
  image:
  'https://images.unsplash.com/photo-1558002038-1055907df827?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'Centralized touchscreen control panel for managing all Werker heating, cooling, and ventilation systems from one interface.',
  specs: [
  { label: 'Display', value: '7-inch OLED' },
  { label: 'Connectivity', value: 'Wi-Fi / Bluetooth' },
  { label: 'Compatibility', value: 'All Werker Systems' }]

},
{
  id: 8,
  name: 'External Heat Pump Unit',
  type: 'Heating & Cooling',
  price: '$3,400',
  image:
  'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  description:
  'High-capacity external air-source heat pump. Provides powerful climate control without invasive interior ductwork.',
  specs: [
  { label: 'Capacity', value: '3 Ton' },
  { label: 'SEER Rating', value: '20' },
  { label: 'Operating Range', value: '-15°F to 115°F' }]

}];