import React from 'react';
import { ArrowRight, ThermometerSun, Droplets, Wind } from 'lucide-react';
import { motion } from 'framer-motion';
export function Hero() {
  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    document.querySelector('#contact')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  return (
    <section
      id="hero"
      className="relative h-screen bg-brandBlack flex items-center overflow-hidden pt-20">
      
      {/* Dynamic Layered Gradient Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-gray-800 via-brandBlack to-brandBlack opacity-80"></div>
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary/10 rounded-full blur-[150px] pointer-events-none mix-blend-screen"></div>
      <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-orange-600/10 rounded-full blur-[120px] pointer-events-none mix-blend-screen"></div>

      {/* Technical Grid Overlay */}
      <div className="absolute inset-0 bg-grid-pattern bg-[size:40px_40px] opacity-15 mix-blend-overlay"></div>

      {/* Diagonal Technical Lines */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary to-transparent transform -rotate-12"></div>
        <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary to-transparent transform -rotate-12"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 w-full grid lg:grid-cols-12 gap-12 items-center relative z-20">
        <motion.div
          initial={{
            opacity: 0,
            x: -30
          }}
          animate={{
            opacity: 1,
            x: 0
          }}
          transition={{
            duration: 0.8,
            ease: 'easeOut'
          }}
          className="lg:col-span-7">
          
          <div className="flex gap-3 mb-8">
            <span className="flex items-center gap-1.5 text-primary text-sm font-bold uppercase tracking-widest bg-primary/10 px-4 py-1.5 rounded-full border border-primary/30 backdrop-blur-sm">
              <Droplets size={16} /> Plumbing
            </span>
            <span className="flex items-center gap-1.5 text-primary text-sm font-bold uppercase tracking-widest bg-primary/10 px-4 py-1.5 rounded-full border border-primary/30 backdrop-blur-sm">
              <ThermometerSun size={16} /> Heating
            </span>
            <span className="flex items-center gap-1.5 text-primary text-sm font-bold uppercase tracking-widest bg-primary/10 px-4 py-1.5 rounded-full border border-primary/30 backdrop-blur-sm">
              <Wind size={16} /> Cooling
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-brandWhite leading-[1.05] mb-6 drop-shadow-lg">
            Engineered for <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-orange-400 to-yellow-500">
              Perfect Climate.
            </span>
          </h1>

          <p className="text-lg md:text-xl text-brandWhite/80 mb-10 max-w-xl leading-relaxed font-light">
            Werker is a family-owned technical firm specializing in advanced
            plumbing, heating, and cooling systems. We design and install robust
            solutions that stand the test of time, without compromising your
            home's integrity.
          </p>

          <div className="flex flex-wrap gap-4">
            <a
              href="#contact"
              onClick={scrollToContact}
              className="bg-primary text-brandWhite px-8 py-4 rounded-sm font-bold flex items-center gap-2 hover:bg-white hover:text-brandBlack transition-all group shadow-[0_0_20px_rgba(241,90,36,0.4)] hover:shadow-[0_0_30px_rgba(255,255,255,0.4)]">
              
              Request a Consultation
              <ArrowRight
                size={20}
                className="group-hover:translate-x-1 transition-transform" />
              
            </a>
            <a
              href="#projects"
              className="bg-brandBlack/50 backdrop-blur-md text-brandWhite border border-white/20 px-8 py-4 rounded-sm font-bold hover:bg-white/10 transition-all">
              
              View Our Work
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{
            opacity: 0,
            scale: 0.9
          }}
          animate={{
            opacity: 1,
            scale: 1
          }}
          transition={{
            duration: 1,
            delay: 0.2,
            ease: 'easeOut'
          }}
          className="hidden lg:flex lg:col-span-5 relative h-full items-center justify-center">
          
          {/* Large Bold Icons Composition */}
          <div className="relative w-full aspect-square max-w-[500px]">
            {/* Central glowing core */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-64 h-64 bg-primary/20 rounded-full blur-[60px] animate-pulse"></div>
            </div>

            {/* Heating Icon */}
            <motion.div
              initial={{
                y: 20,
                opacity: 0
              }}
              animate={{
                y: 0,
                opacity: 1
              }}
              transition={{
                delay: 0.4,
                duration: 0.8
              }}
              className="absolute top-0 right-10 bg-gradient-to-br from-brandBlack to-gray-900 p-8 rounded-2xl border border-white/10 shadow-2xl backdrop-blur-xl z-30 transform rotate-6 hover:rotate-0 transition-transform duration-500">
              
              <ThermometerSun
                size={80}
                className="text-primary mb-4"
                strokeWidth={1.5} />
              
              <div className="text-brandWhite font-display font-bold text-xl tracking-wider">
                HEATING
              </div>
              <div className="text-brandWhite/50 text-xs uppercase tracking-widest mt-1">
                Thermal Control
              </div>
            </motion.div>

            {/* Cooling Icon */}
            <motion.div
              initial={{
                x: 20,
                opacity: 0
              }}
              animate={{
                x: 0,
                opacity: 1
              }}
              transition={{
                delay: 0.6,
                duration: 0.8
              }}
              className="absolute bottom-10 right-0 bg-gradient-to-br from-brandBlack to-gray-900 p-8 rounded-2xl border border-white/10 shadow-2xl backdrop-blur-xl z-20 transform -rotate-6 hover:rotate-0 transition-transform duration-500">
              
              <Wind
                size={80}
                className="text-blue-400 mb-4"
                strokeWidth={1.5} />
              
              <div className="text-brandWhite font-display font-bold text-xl tracking-wider">
                COOLING
              </div>
              <div className="text-brandWhite/50 text-xs uppercase tracking-widest mt-1">
                Air Dynamics
              </div>
            </motion.div>

            {/* Plumbing Icon */}
            <motion.div
              initial={{
                x: -20,
                opacity: 0
              }}
              animate={{
                x: 0,
                opacity: 1
              }}
              transition={{
                delay: 0.8,
                duration: 0.8
              }}
              className="absolute top-1/3 -left-10 bg-gradient-to-br from-brandBlack to-gray-900 p-8 rounded-2xl border border-white/10 shadow-2xl backdrop-blur-xl z-40 transform -rotate-3 hover:rotate-0 transition-transform duration-500">
              
              <Droplets
                size={80}
                className="text-cyan-400 mb-4"
                strokeWidth={1.5} />
              
              <div className="text-brandWhite font-display font-bold text-xl tracking-wider">
                PLUMBING
              </div>
              <div className="text-brandWhite/50 text-xs uppercase tracking-widest mt-1">
                Fluid Systems
              </div>
            </motion.div>

            {/* Connecting technical lines */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none z-10 opacity-30"
              viewBox="0 0 500 500">
              
              <path
                d="M 150 250 L 350 150"
                stroke="url(#orange-grad)"
                strokeWidth="2"
                strokeDasharray="5,5"
                fill="none" />
              
              <path
                d="M 150 250 L 350 350"
                stroke="url(#orange-grad)"
                strokeWidth="2"
                strokeDasharray="5,5"
                fill="none" />
              
              <path
                d="M 350 150 L 350 350"
                stroke="url(#orange-grad)"
                strokeWidth="2"
                strokeDasharray="5,5"
                fill="none" />
              
              <defs>
                <linearGradient
                  id="orange-grad"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="0%">
                  
                  <stop offset="0%" stopColor="#f15a24" />
                  <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </motion.div>
      </div>
    </section>);

}