import React, { useEffect, useState } from 'react';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { Modal } from '../components/Modal';
import { ArrowRight, Maximize2, ShoppingCart, ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { productsData, Product } from '../data/shopData';
export function ShopPage() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const navigate = useNavigate();
  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const handleActionClick = () => {
    setSelectedProduct(null);
    // Navigate back to home and scroll to contact
    navigate('/#contact');
    setTimeout(() => {
      document.querySelector('#contact')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  return (
    <div className="w-full min-h-screen bg-brandWhite font-sans selection:bg-primary selection:text-white flex flex-col">
      <Navbar />

      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-12">
            <Link
              to="/"
              className="inline-flex items-center text-brandBlack/60 hover:text-primary font-medium mb-6 transition-colors">
              
              <ArrowLeft size={18} className="mr-2" /> Back to Home
            </Link>
            <h1 className="text-5xl font-display font-bold text-brandBlack mb-4">
              Equipment Shop
            </h1>
            <p className="text-xl text-brandBlack/60 max-w-2xl">
              Browse our complete catalog of premium heating, cooling, and
              plumbing hardware. Professional-grade equipment for lasting
              performance.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {productsData.map((product) =>
            <div
              key={product.id}
              className="group relative overflow-hidden rounded-sm cursor-pointer bg-brandBlack border border-gray-200 shadow-sm"
              onClick={() => setSelectedProduct(product)}>
              
                <div className="aspect-[4/3] overflow-hidden bg-white">
                  <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover mix-blend-multiply transition-transform duration-700 group-hover:scale-110" />
                
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-brandBlack via-brandBlack/60 to-transparent opacity-90 group-hover:opacity-95 transition-opacity"></div>

                <div className="absolute inset-0 p-6 flex flex-col justify-end text-brandWhite">
                  <div className="flex justify-between items-end mb-2">
                    <span className="text-primary text-xs font-bold uppercase tracking-wider">
                      {product.type}
                    </span>
                    <span className="text-lg font-display font-bold">
                      {product.price}
                    </span>
                  </div>
                  <h4 className="text-xl font-display font-bold mb-3">
                    {product.name}
                  </h4>
                  <div className="flex items-center text-sm font-medium text-brandWhite/70 group-hover:text-primary transition-colors">
                    View Details{' '}
                    <ArrowRight
                    size={16}
                    className="ml-2 group-hover:translate-x-1 transition-transform" />
                  
                  </div>
                </div>

                <div className="absolute top-4 right-4 w-10 h-10 bg-brandBlack/50 backdrop-blur rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0">
                  <Maximize2 size={18} className="text-brandWhite" />
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />

      <Modal
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}>
        
        {selectedProduct &&
        <div className="flex flex-col md:flex-row">
            <div className="md:w-1/2 bg-brandGray-50 p-8 flex items-center justify-center">
              <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="w-full max-w-md object-cover mix-blend-multiply rounded-sm shadow-lg" />
            
            </div>
            <div className="md:w-1/2 p-8 md:p-12 bg-brandWhite text-brandBlack flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <span className="text-primary text-sm font-bold uppercase tracking-wider">
                  {selectedProduct.type}
                </span>
                <span className="text-2xl font-display font-bold text-brandBlack">
                  {selectedProduct.price}
                </span>
              </div>
              <h3 className="text-3xl font-display font-bold mb-6">
                {selectedProduct.name}
              </h3>

              <p className="text-brandBlack/70 leading-relaxed mb-8">
                {selectedProduct.description}
              </p>

              <div className="mb-10">
                <h4 className="text-sm font-bold text-brandBlack/50 uppercase tracking-wider mb-4">
                  Specifications
                </h4>
                <div className="space-y-3">
                  {selectedProduct.specs.map((spec, idx) =>
                <div
                  key={idx}
                  className="flex justify-between border-b border-gray-100 pb-2">
                  
                      <span className="text-brandBlack/60">{spec.label}</span>
                      <span className="font-medium">{spec.value}</span>
                    </div>
                )}
                </div>
              </div>

              <div className="mt-auto flex flex-col sm:flex-row gap-4">
                <button
                onClick={handleActionClick}
                className="flex-1 bg-primary text-brandWhite py-4 rounded-sm font-bold hover:bg-orange-600 transition-colors text-center">
                
                  Order Product
                </button>
                <button
                onClick={handleActionClick}
                className="flex-1 bg-brandBlack text-brandWhite py-4 rounded-sm font-bold hover:bg-gray-800 transition-colors text-center">
                
                  Request Installation
                </button>
              </div>
            </div>
          </div>
        }
      </Modal>
    </div>);

}